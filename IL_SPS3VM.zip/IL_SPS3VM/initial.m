function out=initial(original_x,original_y,extended_x,extended_y)
    out=SemiSVMCall(original_x,original_y,extended_x,extended_y);
end
