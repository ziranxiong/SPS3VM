dataType = 8;

load(['F:\nkp\ILS3VM_blance_xm\output\finish_res\data',num2str(dataType),'.mat']);
save(['F:\nkp\ILS3VM_blance_xm\output\finish_res\data',num2str(dataType),'.mat']);
